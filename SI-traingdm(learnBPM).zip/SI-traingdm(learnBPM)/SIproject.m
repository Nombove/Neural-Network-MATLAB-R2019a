clear
format compact

load('pima.mat');

Pn=Pns;
T=Ts;
S1_vec = 5:5:50;
S2_vec = S1_vec;
[R,~] = size(P);
[S3,Q] = size(T);
lr_vec = [1e-4 1e-5 1e-6];
mc_vec = [0.1:0.1:0.9 0.95 0.99];
PK_v4 = zeros(length(S1_vec),length(S2_vec),length(lr_vec),length(mc_vec));
SSE_v4 = PK_v4;
% sprawdzi� u�ywan� miare b��du, tzn. sse (0.25) czy mse=SSE/degree_of_freedom(0.25/150)
liczba_petli = 0;
for ind_S1=1:length(S1_vec)
    for ind_S2=1:ind_S1
        for ind_lr=1:length(lr_vec)
            for ind_mc=1:length(mc_vec)
                liczba_petli = liczba_petli + 1;
            end
        end
    end
end
petla = 0;
tic
for ind_S1=1:length(S1_vec)
    for ind_S2=1:ind_S1
        for ind_lr=1:length(lr_vec)
            for ind_mc=1:length(mc_vec)
                net = feedforwardnet([S1_vec(ind_S1) S2_vec(ind_S2)],'traingdm');
                net.trainParam.lr = lr_vec(ind_lr); 
                net.trainParam.epochs = 2000;
                net.trainParam.goal = 0.25/Q; %liczba_rekordow(768)
                net.trainParam.mc=mc_vec(ind_mc);
                %net.trainParam.showCommandLine=true;
                net.trainParam.max_fail=100;
                [net,tr] = train(net,Pn,T);
                y = net(Pn);
                PK = (1-sum(abs(T-y)>=.5)/length(T))*100 %Poprawno�� Klasyfikacji
                PK_v4 (ind_S1, ind_S2, ind_lr, ind_mc) = PK;
                SSE_v4(ind_S1, ind_S2, ind_lr, ind_mc) = tr.best_perf; 
                t=toc;
                petla = petla + 1;
                [petla/liczba_petli*100 t t/petla*(liczba_petli-petla)]
            end
        end
    end
end

    


%mesh
%mesh




%{
load('pima.mat');
p=Pns;
t=Ts;
net = feedforwardnet(3,'traingdm');
net.trainParam.lr = 0.01;
net.trainParam.mc = 0.9;
net.trainParam.max_fail=100;
net = train(net,p,t);
y = net(p);
%}